addpath Classification Test\Results\
%% Caricamento Dataset
%%% Scelte disponibili: "ChatGPT" % "Claude" % "Grok" % "DeepSeek" 
Dataset = "ChatGPT";
[datasetsize, Dataset_Message_list, Dataset_Update_ID_list, Dataset_chat_ID_list, Correct_Class_list] = Classification_Dataset_Setup(Dataset);
Classification_results_Test = struct();

%%% Classi disponibili
classNames = ["START", "RESET", "QUESTION", "CHANGE", ...
    "SIMULATION", "INSULT", "ADVICE_ON", "ADVICE_OFF", ...
    "LOAD_PLANNING", "AUTO_PLANNING_ON", "AUTO_PLANNING_OFF", ...
    "BESS_COORD_ON", "BESS_COORD_OFF", "LOAD_COORD_ON", ...
    "LOAD_COORD_OFF", "ADVICE_COORD_ON", "ADVICE_COORD_OFF", ...
    "MSG_ABORT", "CLASSLESS", "EMS_OTHER", "MSG_NOT_READY", "MSG_READY", "MSG_OTHER"];

%%% Lista classificatori
Classificator_list = ["Local_old", "Local_freeze", "Local_freeze2", ...
                      "LLM_nano_low_nocatch", "LLM_luna_low", "LLM_sol_low", "LLM_nano_low", "LLM_luna_high", "LLM_sol_high", ...
                      "Hybrid_nano_low_nocatch", "Hybrid_nano_low", "Hybrid_luna_low", "Hybrid_sol_low", "Hybrid_nano_high", "Hybrid_luna_high", "Hybrid_sol_high", ...
                      "Single_nano_high_nocatch", "Single_nano_high","Single_nano_low","Single_luna_high", "Single_sol_high", "Single_luna_low", "Single_sol_low", "Single_sol_high_R2", "Single_luna_low_R2", "Single_sol_low_R2",...
                      "HSingle_luna_low", "HSSingle_luna_low", ...
                      "Single_luna_low_Grok", "HSingle_luna_low_Grok", "HSSingle_luna_low_Grok", ...
                      "Single_luna_low_DeepSeek", "HSingle_luna_low_DeepSeek", "HSSingle_luna_low_DeepSeek", ...
                      "Single_luna_low_Claude", "HSingle_luna_low_Claude", "HSSingle_luna_low_Claude", ...
                      "Single_nano_low_Grok", "HSingle_nano_low_Grok", "HSSingle_nano_low_Grok", ...
                      "Single_nano_low_DeepSeek", "HSingle_nano_low_DeepSeek", "HSSingle_nano_low_DeepSeek", ...
                      "Single_nano_low_Claude", "HSingle_nano_low_Claude", "HSSingle_nano_low_Claude", ...
                      "HSingle_nano_low", "HSSingle_nano_low", ...
                      "Single_haiku_low_Grok", "HSingle_haiku_low_Grok", "HSSingle_haiku_low_Grok", ...
                      "Single_haiku_low_DeepSeek", "HSingle_haiku_low_DeepSeek", "HSSingle_haiku_low_DeepSeek", ...
                      "Single_haiku_low_Claude", "HSingle_haiku_low_Claude", "HSSingle_haiku_low_Claude", ...
                      "Single_haiku_low", "HSingle_haiku_low", "HSSingle_haiku_low"];
N_Classificator = size(Classificator_list,2);
%%% Risultati Simulazione

for C = 1:N_Classificator
    Classificator = Classificator_list(C);
    Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
    EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
    EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
    Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");
    
    %%% Ordinamento Risultati
    load(Conversation_Status_name)
    Class_Result = repmat("",1,datasetsize);
    for D = datasetsize:-1:1
        Class_Result(D) = Class_list(D).MAIN;
        switch Class_Result(D)
            case "EMS"
                Class_Result(D) = Class_list(D).EMS;
    
            case "ADMIN"
                Class_Result(D) = Class_list(D).ADMIN;
    
                switch Class_Result(D)
                    case "EMS"
                        Class_Result(D) = Class_list(D).ADMIN_EMS;
        
                    case "BROADCAST"
                        Class_Result(D) = Class_list(D).ADMIN_BRD;
                end
        end
    end
    
    load(Dataset_Results_name)
    %%% Total latency
    Total_Latency_s = sum(Dataset_Latency);
    %%% Token extraction
    Classifier_Token_Usage = [Dataset_Token_Usage.Classifier];
    
    Input_Tokens             = [Classifier_Token_Usage.Input];
    Input_Ordinary_Tokens    = [Classifier_Token_Usage.Input_Ordinary];
    Input_Cached_Tokens      = [Classifier_Token_Usage.Input_Cached];
    Input_Cache_Write_Tokens = [Classifier_Token_Usage.Input_Cache_Write];
    
    Output_Tokens            = [Classifier_Token_Usage.Output];
    Output_Reasoning_Tokens  = [Classifier_Token_Usage.Output_Reasoning];
    
    %%% Totals
    Total_Input_Tokens             = sum(Input_Tokens);
    Total_Input_Ordinary_Tokens    = sum(Input_Ordinary_Tokens);
    Total_Input_Cached_Tokens      = sum(Input_Cached_Tokens);
    Total_Input_Cache_Write_Tokens = sum(Input_Cache_Write_Tokens);
    
    Total_Output_Tokens            = sum(Output_Tokens);
    Total_Output_Reasoning_Tokens  = sum(Output_Reasoning_Tokens);
    
    Classification_results= struct(...
        Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,0,0] ),...
        "Total_Latency_s", Total_Latency_s, ...
        "Input_Tokens", Total_Input_Tokens, ...
        "Input_Ordinary_Tokens", Total_Input_Ordinary_Tokens, ...
        "Input_Cached_Tokens", Total_Input_Cached_Tokens, ...
        "Input_Cache_Write_Tokens", Total_Input_Cache_Write_Tokens, ...
        "Output_Tokens", Total_Output_Tokens, ...
        "Output_Reasoning_Tokens", Total_Output_Reasoning_Tokens);
    
    Classification_results_Test.(Classificator) = Classification_results;
end

save Classification_results_Test.mat Classification_results_Test
