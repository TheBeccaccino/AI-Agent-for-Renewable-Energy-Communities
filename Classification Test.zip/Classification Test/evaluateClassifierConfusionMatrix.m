function results = evaluateClassifierConfusionMatrix(yTrue, yPred, classNames, modelName, classifierType, plot_ON)
% evaluateClassifierConfusionMatrix
%
% Calcola, visualizza e analizza la confusion matrix di un classificatore.
% Genera quattro figure:
%   1) Confusion Matrix con assi numerici
%   2) Confusion Matrix normalizzata con assi numerici
%   3) Confusion Matrix con nomi classe sugli assi
%   4) Confusion Matrix normalizzata con nomi classe sugli assi
%
% Tutte le scritte sono in grassetto.
% Titolo e label degli assi sono in Times New Roman.
%
% INPUT
%   yTrue
%       Etichette corrette.
%       Può essere string array, categorical o cell array di char.
%
%   yPred
%       Etichette predette dal classificatore.
%       Può essere string array, categorical o cell array di char.
%
%   classNames
%       Elenco ordinato di tutte le classi da considerare.
%
%   modelName
%       Nome del modello utilizzato (es. "gpt-5-nano", "gpt-6-luna").
%
%   classifierType
%       Tipo/architettura del classificatore (es. "Local", "Hybrid",
%       "Hierarchical LLM", "Single-stage").
%
%   plot_ON
%       Vettore numerico/logico di quattro elementi:
%           plot_ON(1) -> Confusion Matrix con assi numerici
%           plot_ON(2) -> Confusion Matrix normalizzata con assi numerici
%           plot_ON(3) -> Confusion Matrix con nomi classe
%           plot_ON(4) -> Confusion Matrix normalizzata con nomi classe
%       Esempio: [1 0 1 0] genera solo le figure 1 e 3.
%
% OUTPUT
%   results
%       Struttura contenente:
%           confusionMatrix
%           normalizedConfusionMatrix
%           classNames
%           classIndexTable
%           accuracy
%           balancedAccuracy
%           macroPrecision
%           macroRecall
%           macroF1
%           weightedF1
%           metricsTable
%           figureHandles

    %% Impostazioni grafiche
    plotFontName = 'Times New Roman';
    plotFontWeight = 'bold';

    %% Controllo input

    if nargin < 5
        error(['La funzione richiede almeno cinque input: ', ...
               'yTrue, yPred, classNames, modelName e classifierType.']);
    end

    if nargin < 6 || isempty(plot_ON)
        plot_ON = [1 1 1 1];
    end

    if ~isnumeric(plot_ON) && ~islogical(plot_ON)
        error('plot_ON deve essere un vettore numerico o logico di quattro elementi.');
    end

    if numel(plot_ON) ~= 4
        error('plot_ON deve contenere esattamente quattro elementi.');
    end

    plot_ON = logical(plot_ON(:).');

    modelName = string(modelName);
    classifierType = string(classifierType);

    if ~isscalar(modelName) || ~isscalar(classifierType)
        error('modelName e classifierType devono essere valori scalari.');
    end

    %% Conversione in string array

    yTrue = string(yTrue);
    yPred = string(yPred);
    classNames = string(classNames);

    yTrue = yTrue(:);
    yPred = yPred(:);
    classNames = classNames(:);

    %% Controlli di base

    if isempty(yTrue)
        error('yTrue è vuoto.');
    end

    if isempty(yPred)
        error('yPred è vuoto.');
    end

    if isempty(classNames)
        error('classNames è vuoto.');
    end

    if numel(yTrue) ~= numel(yPred)
        error('yTrue e yPred devono contenere lo stesso numero di elementi.');
    end

    yTrue = strtrim(yTrue);
    yPred = strtrim(yPred);
    classNames = strtrim(classNames);

    if numel(unique(classNames)) ~= numel(classNames)
        error('classNames contiene classi duplicate.');
    end

    unknownTrue = setdiff(unique(yTrue), classNames);
    unknownPred = setdiff(unique(yPred), classNames);

    if ~isempty(unknownTrue)
        error('Classi reali non presenti in classNames: %s', ...
              strjoin(unknownTrue, ', '));
    end

    if ~isempty(unknownPred)
        error('Classi predette non presenti in classNames: %s', ...
              strjoin(unknownPred, ', '));
    end

    %% Preparazione categorical con ordine esplicito

    yTrueCategorical = categorical(yTrue, classNames, classNames);
    yPredCategorical = categorical(yPred, classNames, classNames);
    classOrder = categorical(classNames, classNames, classNames);

    %% Confusion matrix numerica

    confusionMatrix = confusionmat( ...
        yTrueCategorical, ...
        yPredCategorical, ...
        'Order', classOrder);

    %% Confusion matrix normalizzata per riga

    rowTotals = sum(confusionMatrix, 2);

    normalizedConfusionMatrix = zeros(size(confusionMatrix));

    validRows = rowTotals > 0;
    normalizedConfusionMatrix(validRows, :) = ...
        confusionMatrix(validRows, :) ./ rowTotals(validRows);

    %% Etichette asse numeriche e nominali

    numClasses = numel(classNames);

    numericAxisLabels = string(1:numClasses);
    numericAxisLabelsCell = cellstr(numericAxisLabels);

    namedAxisLabelsCell = cellstr(classNames);

    %% Titoli figure
    titleSuffix = " - " + classifierType + " - " + modelName;

    %% Tabella di mapping indice -> nome classe

    classIndexTable = table( ...
        (1:numClasses)', ...
        classNames, ...
        'VariableNames', {'Index', 'ClassName'});

    %% Inizializzazione handle figure
    fig1 = [];
    fig2 = [];
    fig3 = [];
    fig4 = [];

    %% Figure 1: counts con assi numerici
    if plot_ON(1)
        fig1 = figure( ...
            'Name', char("Confusion Matrix - Numeric Labels" + titleSuffix), ...
            'NumberTitle', 'off');

        chart1 = confusionchart(confusionMatrix, numericAxisLabelsCell);
        chart1.Title = char("Confusion Matrix" + titleSuffix);
        chart1.XLabel = 'Predicted Class Index';
        chart1.YLabel = 'True Class Index';

        try
            chart1.RowSummary = 'row-normalized';
        catch
        end

        try
            chart1.ColumnSummary = 'column-normalized';
        catch
        end

        applyChartStyle(chart1, plotFontName, plotFontWeight);
    end

    %% Figure 2: normalized con assi numerici
    if plot_ON(2)
        fig2 = figure( ...
            'Name', char("Normalized Confusion Matrix - Numeric Labels" + titleSuffix), ...
            'NumberTitle', 'off');

        chart2 = confusionchart(confusionMatrix, numericAxisLabelsCell);
        chart2.Title = char("Confusion Matrix normalized with respect to the true class" + titleSuffix);
        chart2.XLabel = 'Predicted Class Index';
        chart2.YLabel = 'True Class Index';

        try
            chart2.Normalization = 'row-normalized';
            applyChartStyle(chart2, plotFontName, plotFontWeight);
        catch
            close(fig2);
            fig2 = figure( ...
                'Name', char("Normalized Confusion Matrix - Numeric Labels" + titleSuffix), ...
                'NumberTitle', 'off');

            imagesc(normalizedConfusionMatrix);
            axis equal;
            axis tight;
            colorbar;

            title( ...
                char("Confusion Matrix normalized with respect to the true class" + titleSuffix), ...
                'FontName', plotFontName, ...
                'FontWeight', plotFontWeight);

            xlabel('Predicted Class Index', ...
                'FontName', plotFontName, 'FontWeight', plotFontWeight);
            ylabel('True Class Index', ...
                'FontName', plotFontName, 'FontWeight', plotFontWeight);

            xticks(1:numClasses);
            yticks(1:numClasses);
            xticklabels(numericAxisLabelsCell);
            yticklabels(numericAxisLabelsCell);

            set(gca, 'FontName', plotFontName, ...
                     'FontWeight', plotFontWeight);

            addMatrixValues(normalizedConfusionMatrix, '%.2f', ...
                plotFontName, plotFontWeight);
        end
    end

    %% Figure 3: counts con nomi classe
    if plot_ON(3)
        fig3 = figure( ...
            'Name', char("Confusion Matrix - Class Names" + titleSuffix), ...
            'NumberTitle', 'off');

        chart3 = confusionchart(confusionMatrix, namedAxisLabelsCell);
        chart3.Title = char("Confusion Matrix" + titleSuffix);
        chart3.XLabel = 'Predicted Class';
        chart3.YLabel = 'True Class';

        try
            chart3.RowSummary = 'row-normalized';
        catch
        end

        try
            chart3.ColumnSummary = 'column-normalized';
        catch
        end

        applyChartStyle(chart3, plotFontName, plotFontWeight);
    end

    %% Figure 4: normalized con nomi classe
    if plot_ON(4)
        fig4 = figure( ...
            'Name', char("Normalized Confusion Matrix - Class Names" + titleSuffix), ...
            'NumberTitle', 'off');

        chart4 = confusionchart(confusionMatrix, namedAxisLabelsCell);
        chart4.Title = char("Confusion Matrix normalized with respect to the true class" + titleSuffix);
        chart4.XLabel = 'Predicted Class';
        chart4.YLabel = 'True Class';

        try
            chart4.Normalization = 'row-normalized';
            applyChartStyle(chart4, plotFontName, plotFontWeight);
        catch
            close(fig4);
            fig4 = figure( ...
                'Name', char("Normalized Confusion Matrix - Class Names" + titleSuffix), ...
                'NumberTitle', 'off');

            imagesc(normalizedConfusionMatrix);
            axis equal;
            axis tight;
            colorbar;

            title( ...
                char("Confusion Matrix normalized with respect to the true class" + titleSuffix), ...
                'FontName', plotFontName, ...
                'FontWeight', plotFontWeight);

            xlabel('Predicted Class', ...
                'FontName', plotFontName, 'FontWeight', plotFontWeight);
            ylabel('True Class', ...
                'FontName', plotFontName, 'FontWeight', plotFontWeight);

            xticks(1:numClasses);
            yticks(1:numClasses);
            xticklabels(namedAxisLabelsCell);
            yticklabels(namedAxisLabelsCell);

            set(gca, 'FontName', plotFontName, ...
                     'FontWeight', plotFontWeight);

            xtickangle(45);

            addMatrixValues(normalizedConfusionMatrix, '%.2f', ...
                plotFontName, plotFontWeight);
        end
    end

    %% Metriche globali

    totalSamples = sum(confusionMatrix(:));
    correctPredictions = trace(confusionMatrix);

    accuracy = correctPredictions / totalSamples;

    %% Metriche per classe

    truePositive = diag(confusionMatrix);
    falsePositive = sum(confusionMatrix, 1)' - truePositive;
    falseNegative = sum(confusionMatrix, 2) - truePositive;
    trueNegative = totalSamples - truePositive - falsePositive - falseNegative;

    precision = safeDivide(truePositive, truePositive + falsePositive);
    recall = safeDivide(truePositive, truePositive + falseNegative);
    specificity = safeDivide(trueNegative, trueNegative + falsePositive);
    f1Score = safeDivide(2 .* precision .* recall, precision + recall);

    support = sum(confusionMatrix, 2);

    %% Metriche aggregate

    macroPrecision = meanIgnoringNaN(precision);
    macroRecall = meanIgnoringNaN(recall);
    macroF1 = meanIgnoringNaN(f1Score);

    balancedAccuracy = macroRecall;

    validWeightedClasses = support > 0 & ~isnan(f1Score);

    if any(validWeightedClasses)
        weightedF1 = sum( ...
            f1Score(validWeightedClasses) .* support(validWeightedClasses)) ...
            / sum(support(validWeightedClasses));
    else
        weightedF1 = NaN;
    end

    %% Tabella metriche

    metricsTable = table( ...
        (1:numClasses)', ...
        classNames, ...
        support, ...
        truePositive, ...
        falsePositive, ...
        falseNegative, ...
        trueNegative, ...
        precision, ...
        recall, ...
        specificity, ...
        f1Score, ...
        'VariableNames', { ...
            'Index', ...
            'Class', ...
            'Support', ...
            'TruePositive', ...
            'FalsePositive', ...
            'FalseNegative', ...
            'TrueNegative', ...
            'Precision', ...
            'Recall', ...
            'Specificity', ...
            'F1Score'});


    writetable( ...
    metricsTable, ...
    'classification_metrics.xlsx');
    %% Output

    results = struct();

    results.confusionMatrix = confusionMatrix;
    results.normalizedConfusionMatrix = normalizedConfusionMatrix;
    results.classNames = classNames;
    results.classIndexTable = classIndexTable;
    results.modelName = modelName;
    results.classifierType = classifierType;
    results.plot_ON = plot_ON;

    results.accuracy = accuracy;
    results.balancedAccuracy = balancedAccuracy;
    results.macroPrecision = macroPrecision;
    results.macroRecall = macroRecall;
    results.macroF1 = macroF1;
    results.weightedF1 = weightedF1;

    results.metricsTable = metricsTable;

    results.figureHandles = struct();
    results.figureHandles.countsNumeric = fig1;
    results.figureHandles.normalizedNumeric = fig2;
    results.figureHandles.countsNames = fig3;
    results.figureHandles.normalizedNames = fig4;

    %% Stampa risultati

    fprintf('\n');
    fprintf('========================================\n');
    fprintf(' RISULTATI DEL CLASSIFICATORE\n');
    fprintf('========================================\n');
    fprintf('Classificatore:              %s\n', char(classifierType));
    fprintf('Modello:                     %s\n', char(modelName));
    fprintf('Numero totale di campioni:   %d\n', totalSamples);
    fprintf('Predizioni corrette:       %d\n', correctPredictions);
    fprintf('Accuracy:                  %.4f\n', accuracy);
    fprintf('Balanced accuracy:         %.4f\n', balancedAccuracy);
    fprintf('Macro precision:           %.4f\n', macroPrecision);
    fprintf('Macro recall:              %.4f\n', macroRecall);
    fprintf('Macro F1-score:            %.4f\n', macroF1);
    fprintf('Weighted F1-score:         %.4f\n', weightedF1);
    fprintf('========================================\n\n');

    disp(metricsTable);
    fprintf('\nTabella indice -> classe:\n');
    disp(classIndexTable);

end


function applyChartStyle(chartObj, fontName, fontWeight)
% Applica stile grafico al confusionchart.
    try
        chartObj.FontName = fontName;
    catch
    end

    try
        chartObj.FontWeight = fontWeight;
    catch
    end
end


function result = safeDivide(numerator, denominator)
% Esegue la divisione evitando problemi con denominatori nulli.
    result = numerator ./ denominator;
    result(denominator == 0) = NaN;
end


function averageValue = meanIgnoringNaN(values)
% Calcola la media ignorando i NaN.
    validValues = values(~isnan(values));

    if isempty(validValues)
        averageValue = NaN;
    else
        averageValue = mean(validValues);
    end
end


function addMatrixValues(matrixValues, numberFormat, fontName, fontWeight)
% Mostra il valore numerico all'interno di ogni cella della matrice.
    [numberOfRows, numberOfColumns] = size(matrixValues);

    for rowIndex = 1:numberOfRows
        for columnIndex = 1:numberOfColumns
            value = matrixValues(rowIndex, columnIndex);

            text( ...
                columnIndex, ...
                rowIndex, ...
                sprintf(numberFormat, value), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'FontName', fontName, ...
                'FontWeight', fontWeight);
        end
    end
end