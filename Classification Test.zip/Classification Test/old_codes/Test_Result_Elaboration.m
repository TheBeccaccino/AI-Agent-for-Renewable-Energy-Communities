addpath Classification Test\Results\
%% Caricamento Dataset
[datasetsize, Dataset_Message_list, Dataset_Update_ID_list, Dataset_chat_ID_list, Correct_Class_list] = Classification_Dataset_Setup(1);
Classification_results_Test = struct();
%%% Risultati Simulazione

classNames = ["START", "RESET", "QUESTION", "CHANGE", ...
    "SIMULATION", "INSULT", "ADVICE_ON", "ADVICE_OFF", ...
    "LOAD_PLANNING", "AUTO_PLANNING_ON", "AUTO_PLANNING_OFF", ...
    "BESS_COORD_ON", "BESS_COORD_OFF", "LOAD_COORD_ON", ...
    "LOAD_COORD_OFF", "ADVICE_COORD_ON", "ADVICE_COORD_OFF", ...
    "MSG_ABORT", "CLASSLESS", "EMS_OTHER", "MSG_NOT_READY", "MSG_READY", "MSG_OTHER"];

%% Classificatore Locale
Classificator = "Local_nano";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%% Classificatori LLM
Classificator = "LLM_nano";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "LLM_luna";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "LLM_sol";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%% Classificatori Hybrid
Classificator = "Hybrid_nano";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "Hybrid_luna";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "Hybrid_sol";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%% Classificatori Single
Classificator = "Single_nano";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "Single_luna";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;

%%
Classificator = "Single_sol";
Conversation_Status_name  = strcat(Classificator,"_conversation_status_CerBot_test");
EMS_Agent_Info_name       = strcat(Classificator,"_EMS_Agent_Info_exchange_test");
EMS_Agent_Admin_Info_name = strcat(Classificator,"_EMS_Agent_Admin_Info_exchange_test");
Dataset_Results_name      = strcat(Classificator,"_Dataset_Result_Test");

%%% Ordinamento Risultati
load(Conversation_Status_name)
Class_Result = repmat("",1,datasetsize);
for D = datasetsize:-1:1
    Class_Result(D) = Class_list(D).MAIN;
    switch Class_Result(D)
        case "EMS"
            Class_Result(D) = Class_list(D).EMS;

        case "ADMIN"
            Class_Result(D) = Class_list(D).ADMIN;

            switch Class_Result(D)
                case "EMS"
                    Class_Result(D) = Class_list(D).ADMIN_EMS;
    
                case "BROADCAST"
                    Class_Result(D) = Class_list(D).ADMIN_BRD;
            end
    end
end

load(Dataset_Results_name)
%%% Total latency
Total_Latency_s = sum(Dataset_Latency);
%%% Token extraction
Cumulative = [Dataset_Token_Usage.Cumulative];
Input_Tokens  = [Cumulative.Input];
Output_Tokens = [Cumulative.Output];
%%% Totals
Total_Input_Tokens  = sum(Input_Tokens);
Total_Output_Tokens = sum(Output_Tokens);

Classification_results= struct(...
    Classificator, evaluateClassifierConfusionMatrix(Correct_Class_list, Class_Result, classNames, "", Classificator, [0,0,1,0] ),...
    "Total_Latency_s", Total_Latency_s, ...
    "Input_Tokens", Total_Input_Tokens, ...
    "Output_Tokens", Total_Output_Tokens);

Classification_results_Test.(Classificator) = Classification_results;